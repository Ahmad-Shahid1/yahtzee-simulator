import javafx.application.Application; // importing application
import javafx.fxml.FXMLLoader; // importing fxml
import javafx.scene.Scene; // importing scene
import javafx.stage.Stage; // importing  stage
import javafx.scene.Parent; // importing parent
 
public class Yahtzee extends Application { // extends application and defines
	public void start(Stage stage) throws Exception{ 
		Parent root = 
				FXMLLoader.load(getClass().getResource("Yahtzee.fxml")); // loads fxml file

		Scene scene = new Scene(root);
		stage.setTitle("Yahtzee!"); // sets title
		stage.setScene(scene);  // sets scene
		stage.show(); // displays the graphic user interface window
		
	}

	public static void main(String[] args){ // main method 
		launch(args); // launches the java fx application
	}
}