import javafx.fxml.FXML; // importing FXML
import javafx.scene.control.Button; // import button
import javafx.scene.control.Label; // importing label
import javafx.scene.control.TextField; // importing textfield
import javafx.scene.layout.AnchorPane; // importing anchor pane  
// mistakenly used anchorpane and then learnt how to make the gui scrollable by putting anchor pane in scrollpane or wrapping it in scroll pane by playing around in the java fx scene builder (went to hierarchy, right clicked on anchor pane and then saw "wrap in" option, chose scrollpane from there.)
// the idea however came from this website https://stackoverflow.com/questions/75001479/how-can-i-scroll-anchorpane-in-javafx#:~:text=All%20you%20need%20to%20do%20to%20make%20an,AnchorPane%28%20new%20Line%2850%2C%2050%2C%20800%2C%2050%29%20%29%3B%20stage.show%28%29%3B
import java.util.Random; // importing random
import javafx.event.ActionEvent; // import action event(learnt about it from reading chapter 12
import java.util.Arrays;
public class YahtzeeController {
    int [] playerOneYahtzeeDice= new int [5]; // array for holding values for player one
    int [] playerTwoYahtzeeDice= new int [5]; // array for holding values for player two

    @FXML
    private TextField countFourPlayerOne; // textfield

    @FXML
    private TextField countOnePlayerTwo; // textfield

    @FXML
    private TextField playerOneFives; // textfield

    @FXML
    private TextField playerTwoYahtzee; // textfield

    @FXML
    private TextField countSixPlayerTwo; // text field

    @FXML
    private TextField countFivePlayerOne; // text field

    @FXML
    private TextField countThreePlayerTwo; // text field

    @FXML
    private TextField playerOneChance; // text field

    @FXML
    private TextField playerTwoSmallStraight; // text field

    @FXML
    private TextField playerOneThreeOfAKind; // text field

    @FXML
    private TextField playerTwoSixes; // text field

    @FXML
    private TextField playerOneFullHouse; // textfield

    @FXML
    private TextField playerTwoFives; // text field

    @FXML
    private TextField playerTwoFullHouse; // textfield

    @FXML
    private TextField countTwoPlayerTwo; // text field

    @FXML
    private Button rerollButton; // button for rerolling dice

    @FXML
    private TextField countSixPlayerOne; // text field

    @FXML
    private TextField countFourPlayerTwo; // textfield

    @FXML
    private TextField playerTwoAces; // textfield

    @FXML
    private TextField playerTwoFours; // textfield

    @FXML
    private TextField playerOneAces; // textfield

    @FXML
    private TextField playerOneTwos; // textfield

    @FXML
    private TextField playerTwoThreeOfAKind; // textfield

    @FXML
    private TextField playerOneThrees; // textfield

    @FXML
    private TextField playerOneLargeStraight;// textfield

    @FXML
    private TextField playerTwoLargeStraight; // textfield

    @FXML
    private TextField playerOneYahtzee; // textfield

    @FXML
    private AnchorPane YahtzeeAnchorPane; // main container but wrapped in scroll pane

    @FXML
    private TextField playerOneFours; // textfield

    @FXML
    private TextField playerOneSmallStraight; // textfield

    @FXML
    private TextField playerTwoChance; // textfield

    @FXML
    private Label YAHTZEE; // label for the game title

    @FXML
    private TextField playerTwoThrees; // textfield

    @FXML
    private TextField playerOneFourOfAKind; // textfield

    @FXML
    private TextField countThreePlayerOne; // textfield

    @FXML
    private TextField countTwoPlayerOne; // text field

    @FXML
    private TextField playerTwoTwos; // text field

    @FXML
    private TextField playerOneSixes; // text field

    @FXML
    private TextField playerTwoFourOfAKind; // text field

    @FXML
    private TextField countOnePlayerOne; // text field

    @FXML
    private TextField countFivePlayerTwo; // text field

    @FXML
    void rollDice(ActionEvent event){
        Random rand= new Random();
        int [] playerOneFaceVal= new int [6]; // intializes
        for (int x=0; x<5;x++){ // loop
            playerOneYahtzeeDice[x]= rand.nextInt(6)+1; // intializes
            playerOneFaceVal[playerOneYahtzeeDice[x]-1]++; // intializes
        }
        int [] playerTwoFaceVal = new int [6]; // intializes
        for (int x=0; x<5;x++){ // loop
            playerTwoYahtzeeDice[x]= rand.nextInt(6)+1; // intializes
            playerTwoFaceVal[playerTwoYahtzeeDice[x]-1]++; // intializes
        System.out.println("The Dice of player one rolls"); //  print statement
        }
        for (int x=0; x <5; x++){ //  for loop
            System.out.println("The Die"+(x+1)+":"+playerOneYahtzeeDice[x]);
        }
        System.out.println("The Dice of player two rolls"); // print statement
        for (int x=0; x <5; x++){ //  for loop
            System.out.println("The Die"+(x+1)+":"+playerTwoYahtzeeDice[x]);
        }
        boolean playerOneHasYahtzee= true;// boolean statement
        for (int x=1; x < 5;x++){ //  loop 
            if (playerOneYahtzeeDice[x] !=playerOneYahtzeeDice[0]){ // conditional statement
                playerOneHasYahtzee=false; // boolean statement
                break;
            }
        }
        boolean playerTwoHasYahtzee= true; // boolean statement
        for (int x=1; x < 5;x++){ // for loop
            if (playerTwoYahtzeeDice[x] !=playerTwoYahtzeeDice[0]){ // conditional statement
                playerTwoHasYahtzee=false; // boolean statement
                break;


            }
    
        }
        // 14.3.8 String Method valueOf learnt about String.valueOf from the section mentioned, this is in the Java Late Objects book, couldn't use toString method because it doesn't work on primitive types like int
        playerOneAces.setText(String.valueOf(sumOfAllFaces(playerOneYahtzeeDice,1))); //  updates results for this category for player 1
        playerTwoAces.setText(String.valueOf(sumOfAllFaces(playerTwoYahtzeeDice,1))); //  updates results for player 2 in this category
        playerOneTwos.setText(String.valueOf(sumOfAllFaces(playerOneYahtzeeDice,2))); //  updates results for this category for player 1
        playerTwoTwos.setText(String.valueOf(sumOfAllFaces(playerTwoYahtzeeDice,2))); //  updates results for player 2 in this category
        playerOneThrees.setText(String.valueOf(sumOfAllFaces(playerOneYahtzeeDice,3))); // updates results for this category for player 1
        playerTwoThrees.setText(String.valueOf(sumOfAllFaces(playerTwoYahtzeeDice,3))); // updates results for player 2 in this category
        playerOneFours.setText(String.valueOf(sumOfAllFaces(playerOneYahtzeeDice,4)));// updates results for this category for player 1
        playerTwoFours.setText(String.valueOf(sumOfAllFaces(playerTwoYahtzeeDice,4))); // updates results for player 2 in this category
        playerOneFives.setText(String.valueOf(sumOfAllFaces(playerOneYahtzeeDice,5))); // updates results for this category for player 1
        playerTwoFives.setText(String.valueOf(sumOfAllFaces(playerTwoYahtzeeDice,5)));  // updates results for player 2 in this category
        playerOneSixes.setText(String.valueOf(sumOfAllFaces(playerOneYahtzeeDice,6))); // updates results for this category for player 1
        playerTwoSixes.setText(String.valueOf(sumOfAllFaces(playerTwoYahtzeeDice,6)));// updates results for player 2 in this category
        playerOneFullHouse.setText(String.valueOf(methodFullHouse(playerOneYahtzeeDice))); // updates results for this category for player 1
        playerTwoFullHouse.setText(String.valueOf(methodFullHouse(playerTwoYahtzeeDice))); // updates results for player 2 in this category
        playerOneChance.setText(String.valueOf(methodChance(playerOneYahtzeeDice))); // updates results for this category for player 1
        playerTwoChance.setText(String.valueOf(methodChance(playerTwoYahtzeeDice))); // updates results for player 2 in this category
        playerOneThreeOfAKind.setText(String.valueOf(methodThreeOfAKind(playerOneYahtzeeDice))); // updates results for this category for player 1
        playerTwoThreeOfAKind.setText(String.valueOf(methodThreeOfAKind(playerTwoYahtzeeDice))); // updates results for player 2 in this category
        playerOneFourOfAKind.setText(String.valueOf(methodFourOfAKind(playerOneYahtzeeDice))); // updates results for this category for player 1
        playerTwoFourOfAKind.setText(String.valueOf(methodFourOfAKind(playerTwoYahtzeeDice))); // updates results for player 2 in this category
        playerOneYahtzee.setText(String.valueOf(methodYahtzee(playerOneYahtzeeDice))); // updates results for this category for player 1
        playerTwoYahtzee.setText(String.valueOf(methodYahtzee(playerTwoYahtzeeDice))); // updates results for player 2 in this category
        playerOneSmallStraight.setText(String.valueOf(methodSmallStraight(playerOneYahtzeeDice))); // updates results for this category for player 1
        playerTwoSmallStraight.setText(String.valueOf(methodSmallStraight(playerTwoYahtzeeDice))); // updates results for player 2 in this category
        playerOneLargeStraight.setText(String.valueOf(methodLargeStraight(playerOneYahtzeeDice))); // updates results for this category / metho for player 1
        

        

        countOnePlayerOne.setText(String.valueOf(playerOneFaceVal[0])); // updates count for player 1 
        countTwoPlayerOne.setText(String.valueOf(playerOneFaceVal[1])); // updates count for player 1 
        countThreePlayerOne.setText(String.valueOf(playerOneFaceVal[2])); // updates count for player 1 
        countFourPlayerOne.setText(String.valueOf(playerOneFaceVal[3])); // updates count for player 1 
        countFivePlayerOne.setText(String.valueOf(playerOneFaceVal[4])); // updates count for player 1 
        countSixPlayerOne.setText(String.valueOf(playerOneFaceVal[5])); // updates count for player 1 


        countOnePlayerTwo.setText(String.valueOf(playerTwoFaceVal[0])); // updates count for player 2
        countTwoPlayerTwo.setText(String.valueOf(playerTwoFaceVal[1])); // updates count for player 2
        countThreePlayerTwo.setText(String.valueOf(playerTwoFaceVal[2])); // updates count for player 2
        countFourPlayerTwo.setText(String.valueOf(playerTwoFaceVal[3])); // updates count for player 2
        countFivePlayerTwo.setText(String.valueOf(playerTwoFaceVal[4])); // updates count for player 2
        countSixPlayerTwo.setText(String.valueOf(playerTwoFaceVal[5])); // updates count for player 2
    } 
    public static int[] diceRolling(){
        Random randomNumbers= new Random (); // object on random class created and intialized
        int [] sixFacedDice= new int [5]; // intializing array
        for (int x=0;x< 5;x++){ // for loop
            sixFacedDice[x]=randomNumbers.nextInt(6)+1; // intializing and allows the generation of random numbers between 1 and 6
        }
        return sixFacedDice; // returns value
    }
    public static int methodForBestScore (int [] sixFacedDice) { // method
        int highestScorePossible=0; // intializing
        highestScorePossible=Math.max(highestScorePossible,methodForAcesToSixes(sixFacedDice)); // for aces to sixes + intializing
        highestScorePossible= Math.max(highestScorePossible,methodForTheRest(sixFacedDice));// for the rest e.g. three of a kind etcetera + intialzing
        return highestScorePossible; // returns highest score possible
    }
    
    public static int methodForAcesToSixes(int [] sixFacedDice){ // method
        int bestScoreAcesToSixes=0; // intializing
        for (int x=1;x<=6;x++){ // allows iteration
            bestScoreAcesToSixes=Math.max(bestScoreAcesToSixes,sumOfAllFaces(sixFacedDice,x)); // intializing
        }
        return bestScoreAcesToSixes; // returns value
    }
    public static int methodForTheRest (int [] sixFacedDice) { // method
        int lowestScore= 0; // intializing
        for (int x=1;x <=6;x++){ //allows iteration
            switch (x){ 
                case 1 : // runs if x is 1
                    lowestScore= Math.max (lowestScore, methodThreeOfAKind(sixFacedDice));
                    break;
                case 2: // // runs if x is 2
                    lowestScore= Math.max (lowestScore, methodFourOfAKind(sixFacedDice));
                    break;
                case 3: // runs if x is 3
                    lowestScore= Math.max (lowestScore, methodFullHouse(sixFacedDice));
                    break;
                case 4: // runs if x is 4
                    lowestScore= Math.max (lowestScore, methodYahtzee(sixFacedDice));
                    break;
                case 5: // runs if x is 5
                    lowestScore= Math.max (lowestScore, methodSmallStraight(sixFacedDice));
                    break;
                case 6: // runs if x is 6
                    lowestScore= Math.max (lowestScore, methodLargeStraight(sixFacedDice));
                    break;
                default:
                    break;

            }
        }

        lowestScore = Math.max(lowestScore,methodChance(sixFacedDice));
        return lowestScore; // returns value
    }
    public static int sumOfAllFaces (int [] sixFacedDice, int valueOfFace) { // method
        int total=0; // intializing
        for (int dieValue:sixFacedDice){ // allows iteration
            if (dieValue==valueOfFace){ // condition
                total=total+dieValue; // intializing
            }
        }
        return total; // returns value
    }
    public static int methodThreeOfAKind (int [] sixFacedDice){ // method
        for (int x=1;x <=6;x++){// allows iteration + outer loop
            int counter=0; // intializing
            for (int dieValue: sixFacedDice ){ // inner loop + allows iteration
                if (dieValue==x){ // conditional statement
                    counter=counter+1; // intializing
                }
            }
            if (counter >=3){ // conditional statement
                int total=0; // intializing
                for (int dieValue: sixFacedDice){ // loop
                    total=total +dieValue; // intializing
                }
                return total; // returns
            }
        }
        return 0;// returns zero if conditions housed inside the loops aren't true


    }
public static int methodFourOfAKind(int [] sixFacedDice){ // method
        for (int x=1;x <=6;x++){ // outer loop 
    
            int counter= 0 ; // intializing
            for (int dieValue: sixFacedDice){ // inner loop
                if (dieValue==x){ // conditional statement
                    counter++; // incrementing
            }
        }
            if (counter >=4 ){ // conditional statement
                int total=0; // intializing
                for (int dieValue:sixFacedDice){ // loop
                    total=total+dieValue; // intializing + adding dieValue to total
                }   
                return total; // returns value of total if the conditions are true
            }
        }
        return 0; // returns zero if conditions aren't true
    }

    public static int methodFullHouse (int [] sixFacedDice){ // method
        int [] counter2= new int [6]; // intialization  
        for (int dieValue:sixFacedDice){ // loop
            counter2[dieValue-1]++; // incrementing
        }
        boolean valueThree=false; // intializing 
        boolean valueTwo=false; // intializing
        for (int counter:counter2){ // loop
            if (counter==3){ // conditional statement
                valueThree=true; // assigning boolean value  true if counter equals to three
            }
            if (counter==2){ // conditional statement
                valueTwo=true; // assigning value  boolean value true if counter equals to 2
            }
        }
        if (valueThree && valueTwo){ // conditional statement
        return 25; // returns value
        } else { 
            return 0; // returns zero if the condtional statement above is not true
        }
    }
    public static int methodSmallStraight (int [] sixFacedDice){ // method
        int [] orderedSixFacedDice= new int [sixFacedDice.length]; // intializing
        System.arraycopy (sixFacedDice,0,orderedSixFacedDice,0,sixFacedDice.length); //   copies the elements of other arrays
        Arrays.sort(orderedSixFacedDice);

        if (sequenceOfNumbers(orderedSixFacedDice,new int [] {1,2,3,4,5})|| sequenceOfNumbers(orderedSixFacedDice, new int [] {2,3,4,5,6})) { // condtional statement
            return 30; // returns zero if condition above is true
        }
        return 0;
    }
    public static int methodLargeStraight (int [] sixFacedDice){ // method
        int [] orderedSixFacedDice=new int[sixFacedDice.length];
        System.arraycopy (sixFacedDice,0,orderedSixFacedDice,0,sixFacedDice.length); // copies the elements of other arrays
        Arrays.sort(orderedSixFacedDice); // sorts
        if (sequenceOfNumbers(orderedSixFacedDice,new int [] {1,2,3,4,5})|| sequenceOfNumbers(orderedSixFacedDice, new int [] {2,3,4,5,6})) { // conditional statement
            return 40; // returns 40 if the condition is true
        }
        return 0; // returns zero
    }
    public static boolean sequenceOfNumbers (int [] orderedSixFacedDice, int [] order ){ // method
        for (int x=0; x <=orderedSixFacedDice.length-order.length;x++){ // loop
            boolean aMatch= true; // intializing
            for (int i=0;i < order.length;i++){ // inner loop
                if (orderedSixFacedDice[x+i] != order [i]){ // conditional statement
                    aMatch=false; // intializing
                    break;
                }
            }
            if (aMatch) return true;

        }
        return false;
    }
    public static int methodYahtzee (int [] sixFacedDice){ // method
        int die= sixFacedDice[0]; // intializing
        for (int dieValue:sixFacedDice){ // loop
            if (dieValue !=die){ // condition
                return 0; // returns zero if the condition above is true
            }
        }
        return 50;// other wise returns 50
    }
    public static int methodChance (int [] sixFacedDice){ // method
        int total=0; // intializing
        for (int dieValue:sixFacedDice){ // loop
            total=total+dieValue; // intializing
        }
        return total; // returns value of total
    }
}









      